/**
 * @file
 * Ticket type remove script.
 */

(function ($) {
  Drupal.behaviors.ticketUserRegistration = {

      attach: function($context, $settings) {
          }
      }
}(jQuery));
