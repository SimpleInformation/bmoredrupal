A module to refresh a view after a specified time interval. 
Includes advanced options to avoid reloading the whole page, and to avoid causing a full Drupal bootstrap at each refresh.
More info at http://thereisamoduleforthat.com/content/auto-refreshing-views-real-time-information-streams

